const mongoose = require("mongoose");
const Book = require("../models/bookModel");

const getBooks = async (req, res) => {
  try {
    const books = await Book.find();
    res.status(200).json({ status: "OK", Books: books });
  } catch (e) {
    res.status(400).json({ ERROR: e.message });
  }
};

const createBook = async (req, res) => {
  const { isbn, title, author, price } = req.body;
  try {
    await Book.create({
      isbn: isbn,
      title: title,
      author: author,
      price: price,
    });
    res.status(200).json({ status: "Book Created" });
  } catch (e) {
    res.json({ ERROR: e.message });
  }
};

const getBook = async (req, res) => {
  const isbn = req.params.id;
  try {
    const book = await Book.findOne({ isbn: isbn });
    res.status(200).json({ status: "OK", Book: book });
  } catch (e) {
    res.json({ ERROR: e.message });
  }
};

const updateBook = async (req, res) => {
  const isbn = req.params.id;
  const { title, author, price } = req.body;
  const newBook = {
    title: title,
    author: author,
    price: price,
  };
  try {
    await Book.findOneAndUpdate({ isbn: isbn }, newBook);

    res.status(200).json({ status: "OK", Book: newBook });
  } catch (e) {
    res.json({ ERROR: e.message });
  }
};

const deleteBook = async (req, res) => {
  const isbn = req.params.id;
  try {
    const book = await Book.findOneAndDelete({ isbn: isbn });
    res.status(200).json({ status: "OK", Book: book });
  } catch (e) {
    res.json({ ERROR: e.message });
  }
};

module.exports = { getBooks, getBook, createBook, updateBook, deleteBook };
