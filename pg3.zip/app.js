const express = require("express");
const mongoose = require("mongoose");
const {
  getBooks,
  getBook,
  createBook,
  updateBook,
  deleteBook,
} = require("./controllers/booksController");

const app = express();

app.use(express.json());

app.get("/books", getBooks);

app.post("/books", createBook);

app.get("/books/:id", getBook);

app.put("/books/:id", updateBook);

app.delete("/books/:id", deleteBook);

// db connection
mongoose
  .connect("mongodb://localhost:27017/book-store")
  .then(() => {
    app.listen("8000", () => {
      console.log("Listening on port 8000");
    });
  })
  .catch((e) => {
    console.log(`ERROR: ${e}`);
  });
